<%@ Page Language="C#" AutoEventWireup="true" %>
<!DOCTYPE html>
<html lang="id">
<head runat="server">
    <meta charset="utf-8" />
    <title>Asset Management - NexaCore</title>
    <link rel="stylesheet" href="css/site.css" />
</head>
<body>
    <div class="app-shell">
        <div class="sidebar">
            <div class="brand">
                <div class="logo">Nexa<span>Core</span></div>
                <div class="subtitle">IT Operations Platform</div>
            </div>
            <nav>
                <a class="nav-item" href="Default.aspx"><span class="ico">&#9632;</span> Dashboard</a>
                <a class="nav-item active" href="AssetManagement.aspx"><span class="ico">&#9638;</span> Asset Management</a>
                <a class="nav-item" href="ServiceDesk.aspx"><span class="ico">&#9873;</span> Service Desk</a>
                <a class="nav-item" href="SystemMonitor.aspx"><span class="ico">&#9681;</span> System Monitor</a>
                <a class="nav-item" href="MaintenanceConsole.aspx"><span class="ico">&#9881;</span> Maintenance Console</a>
                <a class="nav-item" href="Administration.aspx"><span class="ico">&#9776;</span> Administration</a>
            </nav>
            <div class="footer-note">NexaCore Suite v3.2.1<br />PT Mitra Solusi Digital</div>
        </div>

        <div class="main">
            <div class="topbar">
                <div>
                    <div class="page-title">Asset Management</div>
                    <div class="breadcrumb">Beranda / Asset Management</div>
                </div>
                <div class="user-box">
                    <div class="user-avatar">AD</div>
                    <div>Administrator<br /><span style="color:#8891a3;font-size:11px;">IT Operations</span></div>
                </div>
            </div>

            <div class="content">
                <div class="panel">
                    <div class="panel-header">
                        <div>
                            <h2>Daftar Aset IT</h2>
                            <div class="desc">Inventaris perangkat keras dan infrastruktur perusahaan</div>
                        </div>
                        <button class="btn btn-primary">+ Tambah Aset</button>
                    </div>
                    <div class="panel-body">
                        <table class="data-table">
                            <tr>
                                <th>ID Aset</th><th>Nama</th><th>Tipe</th><th>Lokasi</th><th>Status</th><th>Terakhir Diperiksa</th>
                            </tr>
                            <tr><td>AST-0012</td><td>DB-PROD-01</td><td>Database Server</td><td>Data Center Jakarta</td><td><span class="badge green">Aktif</span></td><td>20 Nov 2026</td></tr>
                            <tr><td>AST-0013</td><td>APP-PROD-02</td><td>Application Server</td><td>Data Center Jakarta</td><td><span class="badge green">Aktif</span></td><td>20 Nov 2026</td></tr>
                            <tr><td>AST-0041</td><td>SW-CORE-01</td><td>Core Switch</td><td>Ruang Server Lt.3</td><td><span class="badge green">Aktif</span></td><td>18 Nov 2026</td></tr>
                            <tr><td>AST-0087</td><td>Laptop Lenovo T14 - a.nugraha</td><td>Workstation</td><td>Kantor Pusat</td><td><span class="badge green">Aktif</span></td><td>15 Nov 2026</td></tr>
                            <tr><td>AST-0102</td><td>FW-EDGE-01</td><td>Firewall</td><td>Data Center Jakarta</td><td><span class="badge yellow">Maintenance</span></td><td>12 Nov 2026</td></tr>
                            <tr><td>AST-0115</td><td>PRN-LT2-03</td><td>Printer Jaringan</td><td>Kantor Pusat Lt.2</td><td><span class="badge gray">Nonaktif</span></td><td>02 Nov 2026</td></tr>
                            <tr><td>AST-0130</td><td>NAS-BACKUP-01</td><td>Storage</td><td>Data Center Jakarta</td><td><span class="badge green">Aktif</span></td><td>19 Nov 2026</td></tr>
                            <tr><td>AST-0144</td><td>AP-LT4-07</td><td>Access Point</td><td>Kantor Pusat Lt.4</td><td><span class="badge red">Bermasalah</span></td><td>21 Nov 2026</td></tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
