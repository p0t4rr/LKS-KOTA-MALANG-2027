# NexaCore IT Operations Platform — Challenge Maintenance Console

Web app ASP.NET Web Forms (.aspx), tema portal manajemen IT perusahaan "NexaCore",
dengan celah **OS Command Injection** yang disengaja di fitur
**Maintenance Console → Alat Diagnostik Jaringan**.

## Struktur menu
1. Dashboard (`Default.aspx`)
2. Asset Management (`AssetManagement.aspx`)
3. Service Desk (`ServiceDesk.aspx`)
4. System Monitor (`SystemMonitor.aspx`)
5. Maintenance Console (`MaintenanceConsole.aspx`) ← **vulnerable**
6. Administration (`Administration.aspx`)

Menu 1, 2, 3, 4, 6 bersifat statis/dekoratif (tabel contoh) untuk memperkuat tema
"portal IT perusahaan" dan menjadi distraksi/red herring. Hanya Maintenance Console
yang memproses input ke backend.

## Lokasi & mekanisme vuln
File: `MaintenanceConsole.aspx`, handler `btnPing_Click`.

```csharp
string arguments = "/c ping -n 4 " + target;   // target = input user, tanpa sanitasi
Process.Start(new ProcessStartInfo("cmd.exe", arguments) { ... });
```

Input dari field "Host / Alamat IP Tujuan" digabung langsung ke argumen `cmd.exe`,
sehingga payload seperti berikut akan tereksekusi di server:

- `127.0.0.1 & whoami`
- `127.0.0.1 && whoami`
- `127.0.0.1 | whoami`
- `127.0.0.1 & type C:\Windows\System32\drivers\etc\hosts`

Output `stdout`/`stderr` dari proses ditampilkan apa adanya (sudah di-HTML-encode agar
tidak ada XSS tambahan, tapi command injection tetap berjalan di level OS sebelum
encoding terjadi).

> Catatan: saya tidak menaruh flag di dalam proyek ini (tidak tahu format/skema
> penilaian yang kalian pakai). Tinggal taruh file flag di server, misalnya
> `C:\flag.txt`, lalu peserta mengambilnya lewat `& type C:\flag.txt`.

## Cara deploy ke server lo (IIS sudah terpasang)
1. Copy folder `nexacore` ini ke server, misalnya ke `C:\inetpub\wwwroot\nexacore`.
2. Buka **IIS Manager** → klik kanan **Sites** → **Add Website**:
   - Site name: `NexaCore`
   - Physical path: `C:\inetpub\wwwroot\nexacore`
   - Binding: port sesuai kebutuhan (mis. `8080`), atau pakai hostname sendiri.
3. Pastikan Application Pool untuk site ini menggunakan **.NET CLR Version v4.0**
   (sudah terpenuhi karena `Web-Asp-Net45` sudah ter-install).
4. Berikan permission **Read & Execute** untuk `IIS_IUSRS` pada folder
   `C:\inetpub\wwwroot\nexacore`.
5. Akses `http://<server>:<port>/` → harus langsung terbuka ke Dashboard.
6. Uji exploit di Maintenance Console dengan payload di atas untuk memastikan
   celah berfungsi sebelum dipakai di event.

## Hardening (jangan lupa setelah event selesai)
File ini sengaja rentan untuk keperluan latihan/CTF. Jangan deploy ke server
produksi atau server yang terekspos ke internet publik tanpa isolasi jaringan
(gunakan VM/lab terisolasi, snapshot, dan firewall yang membatasi akses hanya
untuk peserta).
