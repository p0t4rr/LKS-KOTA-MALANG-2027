<%@ Page Language="C#" AutoEventWireup="true" %>
<!DOCTYPE html>
<html lang="id">
<head runat="server">
    <meta charset="utf-8" />
    <title>System Monitor - NexaCore</title>
    <link rel="stylesheet" href="css/site.css" />
</head>
<body>
    <div class="app-shell">
        <div class="sidebar">
            <div class="brand">
                <div class="logo">Nexa<span>Core</span></div>
                <div class="subtitle">IT Operations Platform</div>
            </div>
            <nav>
                <a class="nav-item" href="Default.aspx"><span class="ico">&#9632;</span> Dashboard</a>
                <a class="nav-item" href="AssetManagement.aspx"><span class="ico">&#9638;</span> Asset Management</a>
                <a class="nav-item" href="ServiceDesk.aspx"><span class="ico">&#9873;</span> Service Desk</a>
                <a class="nav-item active" href="SystemMonitor.aspx"><span class="ico">&#9681;</span> System Monitor</a>
                <a class="nav-item" href="MaintenanceConsole.aspx"><span class="ico">&#9881;</span> Maintenance Console</a>
                <a class="nav-item" href="Administration.aspx"><span class="ico">&#9776;</span> Administration</a>
            </nav>
            <div class="footer-note">NexaCore Suite v3.2.1<br />PT Mitra Solusi Digital</div>
        </div>

        <div class="main">
            <div class="topbar">
                <div>
                    <div class="page-title">System Monitor</div>
                    <div class="breadcrumb">Beranda / System Monitor</div>
                </div>
                <div class="user-box">
                    <div class="user-avatar">AD</div>
                    <div>Administrator<br /><span style="color:#8891a3;font-size:11px;">IT Operations</span></div>
                </div>
            </div>

            <div class="content">
                <div class="stat-grid">
                    <div class="stat-card"><div class="label">Server Terpantau</div><div class="value">12</div></div>
                    <div class="stat-card"><div class="label">Rata-rata CPU</div><div class="value">42%</div></div>
                    <div class="stat-card"><div class="label">Rata-rata Memori</div><div class="value">61%</div></div>
                    <div class="stat-card"><div class="label">Server Bermasalah</div><div class="value">1</div></div>
                </div>

                <div class="panel">
                    <div class="panel-header">
                        <div>
                            <h2>Kesehatan Server</h2>
                            <div class="desc">Pemantauan sumber daya server secara real-time</div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <table class="data-table">
                            <tr><th>Nama Server</th><th>CPU</th><th>Memori</th><th>Disk</th><th>Status</th></tr>
                            <tr><td>DB-PROD-01</td><td>58%</td><td>74%</td><td>65%</td><td><span class="badge green">Normal</span></td></tr>
                            <tr><td>APP-PROD-02</td><td>81%</td><td>88%</td><td>52%</td><td><span class="badge yellow">Tinggi</span></td></tr>
                            <tr><td>WEB-PROD-01</td><td>35%</td><td>49%</td><td>40%</td><td><span class="badge green">Normal</span></td></tr>
                            <tr><td>FILE-SRV-01</td><td>22%</td><td>38%</td><td>91%</td><td><span class="badge red">Disk Penuh</span></td></tr>
                            <tr><td>MAIL-SRV-01</td><td>29%</td><td>44%</td><td>37%</td><td><span class="badge green">Normal</span></td></tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
