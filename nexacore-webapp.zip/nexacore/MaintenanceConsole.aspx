<%@ Page Language="C#" AutoEventWireup="true" %>
<%@ Import Namespace="System.Diagnostics" %>
<!DOCTYPE html>
<html lang="id">
<head runat="server">
    <meta charset="utf-8" />
    <title>Maintenance Console - NexaCore</title>
    <link rel="stylesheet" href="css/site.css" />
</head>
<script runat="server">
    // =========================================================================
    // NOTE (lab environment): fitur "Alat Diagnostik Jaringan" di bawah ini
    // membangun perintah shell dengan menggabungkan string input pengguna secara
    // langsung, tanpa validasi maupun escaping. Ini adalah celah command
    // injection yang disengaja untuk keperluan latihan Maintenance Console.
    // =========================================================================
    protected void btnPing_Click(object sender, EventArgs e)
    {
        string target = txtHost.Text;

        if (string.IsNullOrWhiteSpace(target))
        {
            litOutput.Text = "Masukkan host atau alamat IP tujuan terlebih dahulu.";
            pnlResult.Visible = true;
            return;
        }

        // VULNERABLE: string concatenation langsung ke argumen cmd.exe
        string arguments = "/c ping -n 4 " + target;

        string stdOut = "";
        string stdErr = "";

        try
        {
            ProcessStartInfo psi = new ProcessStartInfo();
            psi.FileName = "cmd.exe";
            psi.Arguments = arguments;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;

            using (Process proc = Process.Start(psi))
            {
                stdOut = proc.StandardOutput.ReadToEnd();
                stdErr = proc.StandardError.ReadToEnd();
                proc.WaitForExit(15000);
            }
        }
        catch (Exception ex)
        {
            stdErr += "\r\n[Exception] " + ex.Message;
        }

        string combined = stdOut;
        if (!string.IsNullOrEmpty(stdErr))
        {
            combined += "\r\n" + stdErr;
        }

        litOutput.Text = Server.HtmlEncode(combined);
        pnlResult.Visible = true;
    }
</script>
<body>
    <div class="app-shell">
        <div class="sidebar">
            <div class="brand">
                <div class="logo">Nexa<span>Core</span></div>
                <div class="subtitle">IT Operations Platform</div>
            </div>
            <nav>
                <a class="nav-item" href="Default.aspx"><span class="ico">&#9632;</span> Dashboard</a>
                <a class="nav-item" href="AssetManagement.aspx"><span class="ico">&#9638;</span> Asset Management</a>
                <a class="nav-item" href="ServiceDesk.aspx"><span class="ico">&#9873;</span> Service Desk</a>
                <a class="nav-item" href="SystemMonitor.aspx"><span class="ico">&#9681;</span> System Monitor</a>
                <a class="nav-item active" href="MaintenanceConsole.aspx"><span class="ico">&#9881;</span> Maintenance Console</a>
                <a class="nav-item" href="Administration.aspx"><span class="ico">&#9776;</span> Administration</a>
            </nav>
            <div class="footer-note">NexaCore Suite v3.2.1<br />PT Mitra Solusi Digital</div>
        </div>

        <div class="main">
            <div class="topbar">
                <div>
                    <div class="page-title">Maintenance Console</div>
                    <div class="breadcrumb">Beranda / Maintenance Console</div>
                </div>
                <div class="user-box">
                    <div class="user-avatar">AD</div>
                    <div>Administrator<br /><span style="color:#8891a3;font-size:11px;">IT Operations</span></div>
                </div>
            </div>

            <div class="content">
                <div class="alert-box">
                    Maintenance Console menyediakan utilitas teknis tingkat lanjut untuk tim IT internal.
                    Gunakan dengan hati-hati karena beberapa alat berinteraksi langsung dengan sistem server.
                </div>

                <div class="panel">
                    <div class="panel-header">
                        <div>
                            <h2>Alat Diagnostik Jaringan</h2>
                            <div class="desc">Jalankan uji konektivitas (ping) ke host atau alamat IP tertentu</div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <form id="form1" runat="server">
                            <div class="form-group">
                                <label for="txtHost">Host / Alamat IP Tujuan</label>
                                <asp:TextBox ID="txtHost" runat="server" CssClass="form-control" placeholder="contoh: 8.8.8.8 atau server-internal.local" />
                            </div>
                            <asp:Button ID="btnPing" runat="server" Text="Jalankan Ping" CssClass="btn btn-primary" OnClick="btnPing_Click" />

                            <asp:Panel ID="pnlResult" runat="server" Visible="false" style="margin-top:18px;">
                                <label style="display:block;font-size:12.5px;font-weight:600;color:#3c4457;margin-bottom:8px;">Hasil Diagnostik</label>
                                <pre class="output-box"><asp:Literal ID="litOutput" runat="server" /></pre>
                            </asp:Panel>
                        </form>
                    </div>
                </div>

                <div class="panel">
                    <div class="panel-header">
                        <div>
                            <h2>Utilitas Lainnya</h2>
                            <div class="desc">Alat pemeliharaan sistem tambahan</div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="tool-grid">
                            <div class="tool-card">
                                <h3>Pembersihan Cache Sistem</h3>
                                <p>Menghapus file cache sementara pada server aplikasi.</p>
                                <button class="btn btn-secondary" type="button" disabled>Jalankan</button>
                            </div>
                            <div class="tool-card">
                                <h3>Restart Layanan</h3>
                                <p>Merestart layanan latar belakang yang dipilih.</p>
                                <button class="btn btn-secondary" type="button" disabled>Jalankan</button>
                            </div>
                            <div class="tool-card">
                                <h3>Ekspor Log Server</h3>
                                <p>Mengekspor log aktivitas server dalam 7 hari terakhir.</p>
                                <button class="btn btn-secondary" type="button" disabled>Jalankan</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
