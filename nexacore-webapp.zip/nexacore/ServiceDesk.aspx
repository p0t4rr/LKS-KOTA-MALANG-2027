<%@ Page Language="C#" AutoEventWireup="true" %>
<!DOCTYPE html>
<html lang="id">
<head runat="server">
    <meta charset="utf-8" />
    <title>Service Desk - NexaCore</title>
    <link rel="stylesheet" href="css/site.css" />
</head>
<body>
    <div class="app-shell">
        <div class="sidebar">
            <div class="brand">
                <div class="logo">Nexa<span>Core</span></div>
                <div class="subtitle">IT Operations Platform</div>
            </div>
            <nav>
                <a class="nav-item" href="Default.aspx"><span class="ico">&#9632;</span> Dashboard</a>
                <a class="nav-item" href="AssetManagement.aspx"><span class="ico">&#9638;</span> Asset Management</a>
                <a class="nav-item active" href="ServiceDesk.aspx"><span class="ico">&#9873;</span> Service Desk</a>
                <a class="nav-item" href="SystemMonitor.aspx"><span class="ico">&#9681;</span> System Monitor</a>
                <a class="nav-item" href="MaintenanceConsole.aspx"><span class="ico">&#9881;</span> Maintenance Console</a>
                <a class="nav-item" href="Administration.aspx"><span class="ico">&#9776;</span> Administration</a>
            </nav>
            <div class="footer-note">NexaCore Suite v3.2.1<br />PT Mitra Solusi Digital</div>
        </div>

        <div class="main">
            <div class="topbar">
                <div>
                    <div class="page-title">Service Desk</div>
                    <div class="breadcrumb">Beranda / Service Desk</div>
                </div>
                <div class="user-box">
                    <div class="user-avatar">AD</div>
                    <div>Administrator<br /><span style="color:#8891a3;font-size:11px;">IT Operations</span></div>
                </div>
            </div>

            <div class="content">
                <div class="panel">
                    <div class="panel-header">
                        <div>
                            <h2>Tiket Dukungan</h2>
                            <div class="desc">Daftar permintaan layanan dan insiden yang dilaporkan pengguna</div>
                        </div>
                        <button class="btn btn-primary">+ Tiket Baru</button>
                    </div>
                    <div class="panel-body">
                        <table class="data-table">
                            <tr>
                                <th>No. Tiket</th><th>Judul</th><th>Pemohon</th><th>Prioritas</th><th>Status</th><th>Tanggal</th>
                            </tr>
                            <tr><td>SD-1042</td><td>Koneksi VPN terputus-putus</td><td>d.pratama</td><td><span class="badge red">Tinggi</span></td><td><span class="badge blue">Diproses</span></td><td>21 Nov 2026</td></tr>
                            <tr><td>SD-1041</td><td>Permintaan instalasi software akuntansi</td><td>f.handayani</td><td><span class="badge gray">Rendah</span></td><td><span class="badge yellow">Menunggu</span></td><td>21 Nov 2026</td></tr>
                            <tr><td>SD-1039</td><td>Printer lantai 2 tidak merespons</td><td>s.kurnia</td><td><span class="badge yellow">Sedang</span></td><td><span class="badge green">Selesai</span></td><td>20 Nov 2026</td></tr>
                            <tr><td>SD-1037</td><td>Akses folder bersama ditolak</td><td>m.ramadhan</td><td><span class="badge yellow">Sedang</span></td><td><span class="badge blue">Diproses</span></td><td>19 Nov 2026</td></tr>
                            <tr><td>SD-1033</td><td>Server ERP lambat saat jam sibuk</td><td>t.wulandari</td><td><span class="badge red">Tinggi</span></td><td><span class="badge yellow">Menunggu</span></td><td>18 Nov 2026</td></tr>
                            <tr><td>SD-1028</td><td>Reset password akun domain</td><td>r.wijaya</td><td><span class="badge gray">Rendah</span></td><td><span class="badge green">Selesai</span></td><td>17 Nov 2026</td></tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
