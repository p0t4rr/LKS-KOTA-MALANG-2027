<%@ Page Language="C#" AutoEventWireup="true" %>
<!DOCTYPE html>
<html lang="id">
<head runat="server">
    <meta charset="utf-8" />
    <title>Dashboard - NexaCore</title>
    <link rel="stylesheet" href="css/site.css" />
</head>
<body>
    <div class="app-shell">
        <div class="sidebar">
            <div class="brand">
                <div class="logo">Nexa<span>Core</span></div>
                <div class="subtitle">IT Operations Platform</div>
            </div>
            <nav>
                <a class="nav-item active" href="Default.aspx"><span class="ico">&#9632;</span> Dashboard</a>
                <a class="nav-item" href="AssetManagement.aspx"><span class="ico">&#9638;</span> Asset Management</a>
                <a class="nav-item" href="ServiceDesk.aspx"><span class="ico">&#9873;</span> Service Desk</a>
                <a class="nav-item" href="SystemMonitor.aspx"><span class="ico">&#9681;</span> System Monitor</a>
                <a class="nav-item" href="MaintenanceConsole.aspx"><span class="ico">&#9881;</span> Maintenance Console</a>
                <a class="nav-item" href="Administration.aspx"><span class="ico">&#9776;</span> Administration</a>
            </nav>
            <div class="footer-note">NexaCore Suite v3.2.1<br />PT Mitra Solusi Digital</div>
        </div>

        <div class="main">
            <div class="topbar">
                <div>
                    <div class="page-title">Dashboard</div>
                    <div class="breadcrumb">Beranda / Dashboard</div>
                </div>
                <div class="user-box">
                    <div class="user-avatar">AD</div>
                    <div>
                        Administrator<br />
                        <span style="color:#8891a3;font-size:11px;">IT Operations</span>
                    </div>
                </div>
            </div>

            <div class="content">
                <div class="stat-grid">
                    <div class="stat-card">
                        <div class="label">Total Aset IT</div>
                        <div class="value">248</div>
                        <div class="trend up">&#9650; 4 aset baru bulan ini</div>
                    </div>
                    <div class="stat-card">
                        <div class="label">Tiket Terbuka</div>
                        <div class="value">17</div>
                        <div class="trend warn">&#9650; 3 prioritas tinggi</div>
                    </div>
                    <div class="stat-card">
                        <div class="label">Uptime Server</div>
                        <div class="value">99.8%</div>
                        <div class="trend up">30 hari terakhir</div>
                    </div>
                    <div class="stat-card">
                        <div class="label">Peringatan Aktif</div>
                        <div class="value">3</div>
                        <div class="trend down">Memerlukan tindak lanjut</div>
                    </div>
                </div>

                <div class="panel">
                    <div class="panel-header">
                        <div>
                            <h2>Aktivitas Terbaru</h2>
                            <div class="desc">Ringkasan aktivitas sistem dalam 24 jam terakhir</div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <table class="data-table">
                            <tr>
                                <th>Waktu</th>
                                <th>Pengguna</th>
                                <th>Aktivitas</th>
                                <th>Modul</th>
                                <th>Status</th>
                            </tr>
                            <tr>
                                <td>08:42</td>
                                <td>b.santoso</td>
                                <td>Memperbarui tiket #SD-1042</td>
                                <td>Service Desk</td>
                                <td><span class="badge green">Berhasil</span></td>
                            </tr>
                            <tr>
                                <td>08:15</td>
                                <td>r.wijaya</td>
                                <td>Menjalankan diagnosa jaringan</td>
                                <td>Maintenance Console</td>
                                <td><span class="badge green">Berhasil</span></td>
                            </tr>
                            <tr>
                                <td>07:58</td>
                                <td>system</td>
                                <td>Pemeriksaan kesehatan server DB-PROD-01</td>
                                <td>System Monitor</td>
                                <td><span class="badge yellow">Peringatan</span></td>
                            </tr>
                            <tr>
                                <td>07:30</td>
                                <td>a.nugraha</td>
                                <td>Menambahkan aset baru (Laptop Lenovo T14)</td>
                                <td>Asset Management</td>
                                <td><span class="badge green">Berhasil</span></td>
                            </tr>
                            <tr>
                                <td>06:55</td>
                                <td>admin</td>
                                <td>Login ke konsol administrasi</td>
                                <td>Administration</td>
                                <td><span class="badge blue">Info</span></td>
                            </tr>
                        </table>
                    </div>
                </div>

                <div class="panel">
                    <div class="panel-header">
                        <div>
                            <h2>Status Layanan</h2>
                            <div class="desc">Kondisi layanan inti perusahaan saat ini</div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <table class="data-table">
                            <tr><th>Layanan</th><th>Status</th><th>Uptime</th></tr>
                            <tr><td>Portal Internal</td><td><span class="badge green">Normal</span></td><td>99.95%</td></tr>
                            <tr><td>Email Perusahaan</td><td><span class="badge green">Normal</span></td><td>99.91%</td></tr>
                            <tr><td>Sistem ERP</td><td><span class="badge yellow">Degradasi</span></td><td>98.40%</td></tr>
                            <tr><td>VPN Gateway</td><td><span class="badge green">Normal</span></td><td>99.99%</td></tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
