<%@ Page Language="C#" AutoEventWireup="true" %>
<!DOCTYPE html>
<html lang="id">
<head runat="server">
    <meta charset="utf-8" />
    <title>Administration - NexaCore</title>
    <link rel="stylesheet" href="css/site.css" />
</head>
<body>
    <div class="app-shell">
        <div class="sidebar">
            <div class="brand">
                <div class="logo">Nexa<span>Core</span></div>
                <div class="subtitle">IT Operations Platform</div>
            </div>
            <nav>
                <a class="nav-item" href="Default.aspx"><span class="ico">&#9632;</span> Dashboard</a>
                <a class="nav-item" href="AssetManagement.aspx"><span class="ico">&#9638;</span> Asset Management</a>
                <a class="nav-item" href="ServiceDesk.aspx"><span class="ico">&#9873;</span> Service Desk</a>
                <a class="nav-item" href="SystemMonitor.aspx"><span class="ico">&#9681;</span> System Monitor</a>
                <a class="nav-item" href="MaintenanceConsole.aspx"><span class="ico">&#9881;</span> Maintenance Console</a>
                <a class="nav-item active" href="Administration.aspx"><span class="ico">&#9776;</span> Administration</a>
            </nav>
            <div class="footer-note">NexaCore Suite v3.2.1<br />PT Mitra Solusi Digital</div>
        </div>

        <div class="main">
            <div class="topbar">
                <div>
                    <div class="page-title">Administration</div>
                    <div class="breadcrumb">Beranda / Administration</div>
                </div>
                <div class="user-box">
                    <div class="user-avatar">AD</div>
                    <div>Administrator<br /><span style="color:#8891a3;font-size:11px;">IT Operations</span></div>
                </div>
            </div>

            <div class="content">
                <div class="panel">
                    <div class="panel-header">
                        <div>
                            <h2>Manajemen Pengguna</h2>
                            <div class="desc">Pengguna dengan akses ke platform NexaCore</div>
                        </div>
                        <button class="btn btn-primary">+ Tambah Pengguna</button>
                    </div>
                    <div class="panel-body">
                        <table class="data-table">
                            <tr><th>Username</th><th>Nama Lengkap</th><th>Peran</th><th>Status</th><th>Login Terakhir</th></tr>
                            <tr><td>admin</td><td>Administrator Sistem</td><td><span class="badge blue">Super Admin</span></td><td><span class="badge green">Aktif</span></td><td>22 Nov 2026, 07:12</td></tr>
                            <tr><td>r.wijaya</td><td>Rian Wijaya</td><td><span class="badge gray">IT Staff</span></td><td><span class="badge green">Aktif</span></td><td>21 Nov 2026, 16:45</td></tr>
                            <tr><td>b.santoso</td><td>Budi Santoso</td><td><span class="badge gray">Service Desk</span></td><td><span class="badge green">Aktif</span></td><td>21 Nov 2026, 15:02</td></tr>
                            <tr><td>a.nugraha</td><td>Andi Nugraha</td><td><span class="badge gray">Asset Manager</span></td><td><span class="badge green">Aktif</span></td><td>21 Nov 2026, 13:30</td></tr>
                            <tr><td>f.handayani</td><td>Fitri Handayani</td><td><span class="badge gray">IT Staff</span></td><td><span class="badge yellow">Nonaktif Sementara</span></td><td>10 Nov 2026, 09:18</td></tr>
                        </table>
                    </div>
                </div>

                <div class="panel">
                    <div class="panel-header">
                        <div>
                            <h2>Pengaturan Sistem</h2>
                            <div class="desc">Konfigurasi umum platform</div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <table class="data-table">
                            <tr><th>Parameter</th><th>Nilai</th></tr>
                            <tr><td>Nama Perusahaan</td><td>PT Mitra Solusi Digital</td></tr>
                            <tr><td>Zona Waktu</td><td>Asia/Jakarta (GMT+7)</td></tr>
                            <tr><td>Kebijakan Password</td><td>Minimal 8 karakter, kombinasi huruf &amp; angka</td></tr>
                            <tr><td>Durasi Sesi Login</td><td>30 menit</td></tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
